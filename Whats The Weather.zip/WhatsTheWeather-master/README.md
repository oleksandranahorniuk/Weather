# WhatsTheWeather
<l>This application is used to find weather information of cities in the world. <br>
This app consumes the openweather API openweatherapi.org<br>
Process data with JSON<br>
